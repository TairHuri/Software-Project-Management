import React from 'react';

const Leads = () => {
  return (
    <div>
      <h1>Welcome to the Leads Page</h1>
      <p>Here are the leads.</p>
    </div>
  );
};

export default Leads;