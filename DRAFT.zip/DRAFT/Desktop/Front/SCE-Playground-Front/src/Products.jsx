import React from 'react';

const Products = () => {
  return (
    <div>
      <h1>Welcome to the Products Page</h1>
      <p>Here are our products.</p>
    </div>
  );
};

export default Products;