import { useState } from 'react';
import sceLogo from './assets/sce_logo.png';
import './App.css';

function App() {

  const [username, setUsername] = useState('');
  const [pass, setPass] = useState('');

  const handleUsernameChange = (e) => {
    const input = e.target.value;
    const regex = /^[a-zA-Z0-9]*$/;
    
    if (regex.test(input)) {
      setUsername(input);
    }
  };

  const handlePasswordChange = (e) => {
    const input = e.target.value;
    const regex = /^[a-zA-Z0-9]*$/;
    
    if (regex.test(input)) {
      setPass(input);
    }
  };

  const handleSubmit = async () => {
    try {
      const response = await fetch('http://localhost:3002/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password: pass })
      });
      
      const data = await response.json();
      if (response.status === 201) {
        alert(data.message); 
      } else {
        alert(data.message); 
      }
    } catch (error) {
      console.error('Error during signup:', error);
    }
  };

  const handleLogIn = async () => {
    try {
      const response = await fetch('http://localhost:3002/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password: pass })
      });

      const data = await response.json();
      if (response.status === 200) {
        alert(data.message); 
      } else {
        alert(data.message); 
      }
    } catch (error) {
      console.error('Error during login:', error.message || error);
    }
  };

  return (
    <>
      <div>
        <a href="https://react.dev" target="_blank">
          <img src={sceLogo} className="logo" alt="sce logo" />
        </a>
      </div>
      <div>
        <label>User Name </label>
        <input 
          type="text" 
          value={username} 
          onInput={handleUsernameChange}
        />
      </div>
      <div>
        <label>Password</label>
        <input 
          type="password" 
          value={pass} 
          onInput={handlePasswordChange}
        />
      </div>
      <div>
        <button onClick={handleSubmit}>Sign up</button>
        <button onClick={handleLogIn}>Login</button>
      </div>
    </>
  );
}

export default App;